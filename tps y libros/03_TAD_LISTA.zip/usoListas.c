#include <stdio.h>
#include "lista.h"

int main()
{
   Lista_T lista;
   int dato;

   lista = CrearLista();
   InsertarPrimero(&lista, 12);

   InsertarPrimero(&lista, 14);
   InsertarPrimero(&lista, 75);
   InsertarUltimo(&lista, 17);
   InsertarUltimo(&lista, 12);  
   InsertarUltimo(&lista, 19);
   InsertarPosicion(&lista, 2, 14);
   RecorrerLista(lista);

   // TODO: eliminar de la lista todos los datos impares



   VaciarLista(&lista);

   return(0);
}
