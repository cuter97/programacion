#include "lista.h"
#include <stdlib.h>
#include <stdio.h>

/* Crea una lista vacia*/
Lista_T Crear_Lista()
{
    Lista_T l;
    l.lista = NULL;
    l.n = 0;

    return(l);
}


/* Inserta el dato x como primer elemento de la lista l*/
int Insertar_Primero(Lista_T *l, int x)
{
    struct Nodo *nuevo;

    if ((nuevo = (struct Nodo*)malloc(sizeof(struct Nodo))) == NULL)
    {
        printf("No se pudo alocar memoria \n");
        exit(-1);
    }

    /* TODO: asignar los valores a los campos dato y sig de nuevo */
    //nuevo->dato = ...;
    //nuevo->sig = ...;

    /* TODO: actualizar l para que apunte al nuevo dato. Incrementar la longitud de la lista */
    //l->lista = ...;
    //l->n = ...;

    return 0;
}


/* Recorre la lista imprimiento por pantalla cada dato */
int Recorrer_Lista(Lista_T l)
{
  struct Nodo *p;

  if(l.n > 0)
  {
    // p apunta al primer elemento de la lista
    p = l.lista;

    // recorro la lista imprimiendo cada uno de los datos
    while (p != NULL)
    {
       /* TODO: imprimir el dato y mover el puntero p*/
       // printf(...);
       // p = ...;
    }
  }
  printf("\n");
   return 0;
}


/* Inserta el dato x como último elemento de la lista l*/
int Insertar_Ultimo(Lista_T *l, int x)
{
   struct Nodo *p, *nuevo;

  // creo el nodo
   nuevo = (struct Nodo*)malloc(sizeof(struct Nodo));

   if (nuevo == NULL) {
      printf("No aloca memoria \n");
      exit (-1);
   } 

   /*TODO: actualizar los campos de nuevo */
   // nuevo->dato = ... ;
   // nuevo->sig = ...;  // será el último nodo de la lista!

     
  
  if (! Lista_Vacia(*l))
  {
      p = l->lista;

  /* TODO: recorrer la lista hasta el último nodo y actualizar el puntero del último nodo */
     while (p->sig != NULL)
     {
         // mover el puntero p al próximo nodo
         //p = ...;
     }

     // p está en el ultimo nodo, se actualiza su campo siguiente para que apunte a "nuevo": dato insertado en último lugar
     p->sig = nuevo;
  }
  else
  {

       /* TODO: lista original vacia, actualizar campo l: */
       //l->lista = ...;
  }

  /* TODO: actualizar la cantidad de datos de la lista */
  // l->n = ...;
}


/* Retorna True si la lista está vacia, FALSE caso contrario*/
int Lista_Vacia(Lista_T l)
{
    /* TODO */
    //return(...);
}


/* Vacia la lista, desalocando memoria alocada por la misma */
int Vaciar_Lista(Lista_T *l)
{
  return 0;
}



/* Suprime el dato x de la lista. Si el dato no existe lo informa y la lista queda sin modificar */
int Suprimir_Dato(Lista_T *l, int x)
{


    return 0;
}


/* Inserta el elemento x en la lista l en la posición pos. Si la posición pos es mayor que la 
   longitud de la lista lo informa y no se modifica la lista */
int Insertar_Dato_Posicion(Lista_T *l, int pos, int x)
{
   
   return 0;

}


/* Retorna la cantidad de elementos de la lista l*/
int Longitud_Lista(Lista_T l)
{
    return l.n;
}


/* Suprime el dato de posición pos de la lista l. Si pos no existe en la lista l
   lo informa y la lista queda sin modificar */
int Suprimir_Dato_Posicion(Lista_T *l, int pos)
{

    return 0;
}


/* Retorna el elemento de posición pos de la lista l. En caso que pos no existe en la lista lo informa.
   En ambos casos la lista no es modificada. */
int Devolver_Dato_Posicion(Lista_T l, int pos)
{
    struct Nodo *act;
    int i;

    if (pos >= 1 && pos <= LongitudLista(l))
    {
        act = l.lista;
        i = 1;
        while (i < pos)
        {
          i++;
          act = act->sig;
        }
        return (act->dato);
    }
    else
    {
      printf("Posicion fuera de rango \n");
      return 0;
    }
}
