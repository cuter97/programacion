#include <stdio.h>
#include <stdlib.h>

// definicion del tipo y función para imprimir dicho tipo
typedef int Tipo_Dato;
void imprimirTipoDato(Tipo_Dato x)
{
   printf(" dato: %d \n", x);
}

#include "ABB.h"

int main()
{
    
    return 0;
}
