#include <stdlib.h>
#include "ABB.h"
#include <stdio.h>


Arbol_T CrearArbol(Tipo_Dato x)
{
    Arbol_T a;
    a = (Arbol_T)malloc(sizeof(struct Nodo));
    a->izq = NULL;
    a->der = NULL;
    a->dato = x;
    return(a);
}


int InsertarElemento(Arbol_T *a, Tipo_Dato dato)
{
    if ((*a) == NULL)
       *a = CrearArbol(dato);
    else
      if (dato < (*a)->dato)
         InsertarElemento(&((*a)->izq), dato);
      else
         InsertarElemento(&((*a)->der), dato);

}

void InOrder(Arbol_T a){
}

void PreOrder(Arbol_T a){
}

void PostOrder(Arbol_T a){  
}

void EliminarElemento(Arbol_T *a, Tipo_Dato dato)
{

    if ((*a) == NULL)
       printf("El dato a eliminar no se encuentra \n");
    else
       if (dato < (*a)->dato)
          EliminarElemento(&((*a)->izq), dato);
       else
         if (dato > (*a)->dato)
            EliminarElemento(&((*a)->der), dato);
         else
         {
             Arbol_T q;
             q = (*a);
             if (q->izq == NULL)
                (*a) = q->der;
             else
               if (q->der == NULL)
                  (*a) = q->izq;
               else
               {  // tiene 2 hijos
                   Arbol_T r, p;
                   p = q;
                   r = q->izq;
                   while (r->der)
                   {
                       p = r;
                       r = r->der;
                   }
                   q->dato = r->dato;
                   if (p == q)
                      p->izq = r->izq;
                   else
                      p->der = r->izq;
                   q = r;
                }
                free(q);
          }

}


int Existe(Arbol_T a, Tipo_Dato dato)
{
   

}

