#include <stdlib.h>

typedef int Tipo_Dato;

struct Nodo
{
    struct Nodo *izq;
    Tipo_Dato dato;
    struct Nodo *der;
};

typedef struct Nodo *Arbol_T;

Arbol_T CrearArbol(Tipo_Dato x);
int InsertarElemento(Arbol_T *a, Tipo_Dato dato);
void InOrder(Arbol_T a);
void PreOrder(Arbol_T a);
void PostOrder(Arbol_T a);
void EliminarElemento(Arbol_T *a, Tipo_Dato dato);
int Existe(Arbol_T a, Tipo_Dato dato);
//completar con el resto de funciones


